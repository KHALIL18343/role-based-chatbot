import os
from pathlib import Path
import unittest
from unittest.mock import patch
from langchain_core.messages import AIMessage
from langchain_core.runnables import RunnableLambda
from streamlit.testing.v1 import AppTest
from chatbot import ChatbotWithRole, PERSONAS

APP = Path(__file__).resolve().parents[1] / "app.py"

def fake_bot(api_key, model, persona):
    return ChatbotWithRole(
        RunnableLambda(lambda _: AIMessage(content="Réponse de test")),
        PERSONAS[persona]["system"],
    )

class AppTests(unittest.TestCase):
    def test_no_key_disables_chat(self):
        with patch.dict(os.environ, {"GOOGLE_API_KEY": "", "GEMINI_API_KEY": ""}):
            app = AppTest.from_file(str(APP)).run()
            self.assertEqual(len(app.exception), 0)
            self.assertTrue(app.chat_input[0].disabled)

    def test_chat_clear_and_role_change(self):
        with patch("chatbot.create_chatbot", side_effect=fake_bot):
            app = AppTest.from_file(str(APP)).run()
            app.text_input(key="api_key_input").set_value("fake-test-key").run()
            self.assertEqual(len(app.exception), 0)
            app.chat_input[0].set_value("Bonjour").run()
            self.assertEqual(len(app.chat_message), 2)
            self.assertEqual(len(app.session_state["chatbot"].chat_conversation), 2)
            app.button[0].click().run()
            self.assertEqual(len(app.chat_message), 0)
            app.chat_input[0].set_value("Autre question").run()
            app.selectbox[0].select("Brief").run()
            self.assertEqual(len(app.chat_message), 0)
            self.assertIn("concisely", app.session_state["chatbot"].prompt.messages[0].content)
            self.assertEqual(len(app.exception), 0)

    def test_api_error_is_shown_without_saving_turn(self):
        def broken_bot(*args):
            bot = fake_bot(*args)
            def fail(_):
                raise RuntimeError("sensitive-provider-detail")
            bot.chat_chain = RunnableLambda(fail)
            return bot
        with patch("chatbot.create_chatbot", side_effect=broken_bot):
            app = AppTest.from_file(str(APP)).run()
            app.text_input(key="api_key_input").set_value("fake-test-key").run()
            app.chat_input[0].set_value("Bonjour").run()
            self.assertEqual(len(app.exception), 0)
            self.assertEqual(len(app.error), 1)
            self.assertNotIn("sensitive-provider-detail", app.error[0].value)
            self.assertEqual(app.session_state["chatbot"].chat_conversation, [])

if __name__ == "__main__":
    unittest.main()

