import unittest
from langchain_core.messages import AIMessage
from langchain_core.runnables import RunnableLambda
from chatbot import ChatbotWithRole, PERSONAS

class ChatbotTests(unittest.TestCase):
    def setUp(self):
        self.requests = []
        def reply(prompt):
            self.requests.append(prompt.to_messages())
            return AIMessage(content="Bonjour !")
        self.bot = ChatbotWithRole(RunnableLambda(reply), "Rôle {littéral}")

    def test_role_and_history(self):
        self.bot.chat("Je suis Amine.")
        self.bot.chat("Quel est mon prénom ?")
        messages = self.requests[-1]
        self.assertEqual([m.type for m in messages], ["system", "human", "ai", "human"])
        self.assertEqual(messages[0].content, "Rôle {littéral}")
        self.assertEqual(messages[1].content, "Je suis Amine.")
        self.assertEqual(len(self.bot.chat_conversation), 4)

    def test_clear_preserves_role(self):
        self.bot.chat("Premier échange")
        self.bot.clear()
        self.bot.chat("Nouveau départ")
        self.assertEqual(len(self.requests[-1]), 2)
        self.assertEqual(self.requests[-1][0].content, "Rôle {littéral}")

    def test_failure_preserves_history(self):
        self.bot.chat("Bonjour")
        previous = list(self.bot.chat_conversation)
        def fail(_):
            raise RuntimeError("API unavailable")
        self.bot.chat_chain = RunnableLambda(fail)
        with self.assertRaises(RuntimeError):
            self.bot.chat("Question")
        self.assertEqual(self.bot.chat_conversation, previous)

    def test_empty_input_and_response(self):
        with self.assertRaises(ValueError):
            self.bot.chat("   ")
        self.bot.chat_chain = RunnableLambda(lambda _: " ")
        with self.assertRaises(ValueError):
            self.bot.chat("Bonjour")
        self.assertEqual(self.bot.chat_conversation, [])

    def test_personas_are_distinct(self):
        self.assertEqual(len({p["system"] for p in PERSONAS.values()}), 3)

if __name__ == "__main__":
    unittest.main()

